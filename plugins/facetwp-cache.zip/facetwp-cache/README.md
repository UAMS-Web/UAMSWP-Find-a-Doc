More information: [FacetWP add-ons](https://facetwp.com/add-ons/caching/)

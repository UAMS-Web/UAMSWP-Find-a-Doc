# FacetWP - Alphabetical Listing
More information: [add-on page](https://facetwp.com/add-ons/alphabetical-listing/)

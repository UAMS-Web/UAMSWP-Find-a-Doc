Official info about translation: http://codex.wordpress.org/Translating_WordPress

Example, translating to French:
Use the ajax-search-pro.pot file and save new copy as ajax-search-pro-fr_FR.po for Spanish.
And then use translating program to translate it to French language, for example PoEdit: https://poedit.net/